package pl.edu.wat.wcy.blackduck.ui.editprofile

class EditProfilePresenter: EditProfileContract.Presenter {

    override fun attachView(view: EditProfileContract.View) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onViewCreated() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onViewDestroyed() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}