package pl.edu.wat.wcy.blackduck.ui.profile

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.recycler_grid_photo.view.*
import pl.edu.wat.wcy.blackduck.R
import pl.edu.wat.wcy.blackduck.data.responses.PostResponse

class ProfileAdapter(private val posts:List<PostResponse>): RecyclerView.Adapter<ProfileAdapter.CustomViewHolder>() {

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        holder?.bindContent(posts[position])
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val layoutInflater = LayoutInflater.from(parent?.context)
        val cellForRow = layoutInflater.inflate(R.layout.recycler_grid_photo, parent, false)
        return CustomViewHolder(cellForRow)
    }
    override fun getItemCount(): Int {
        return posts.size
    }

    class CustomViewHolder(val view: View):RecyclerView.ViewHolder(view) {

        fun bindContent(post: PostResponse){

            Picasso.get()
                .load(post.contentUrl)
                .resize(200, 200)
                .centerCrop()
                .placeholder(R.drawable.loading)
                .error(R.drawable.placeholder)
                .into(view.iv_1)
        }

    }

}