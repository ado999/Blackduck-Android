package pl.edu.wat.wcy.blackduck.data.request

data class GetMessagesRequest(
    val toUserUsername: String
)