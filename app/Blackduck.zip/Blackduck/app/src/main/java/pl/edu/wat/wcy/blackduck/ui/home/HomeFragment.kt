package pl.edu.wat.wcy.blackduck.ui.home

import android.Manifest
import android.content.ContentValues.TAG
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.PermissionChecker.checkSelfPermission
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_home.view.*
import kotlinx.android.synthetic.main.top_menu_main.*
import pl.edu.wat.wcy.blackduck.BlackduckApplication
import pl.edu.wat.wcy.blackduck.R
import pl.edu.wat.wcy.blackduck.data.responses.PostResponse
import pl.edu.wat.wcy.blackduck.ui.message.MessageActivity
import javax.inject.Inject


class HomeFragment : Fragment(), HomeContract.View, SwipeRefreshLayout.OnRefreshListener{

    @Inject
    lateinit var presenter: HomeContract.Presenter

    @Inject
    lateinit var prefs: SharedPreferences

    private var recyclerViewContent = ArrayList<PostResponse>()

    override fun onPostsAvailable(posts: ArrayList<PostResponse>) {
        recyclerViewContent.addAll(posts)
        view?.recycler_view_main?.adapter?.notifyDataSetChanged()
        view?.swipe_container?.isRefreshing = false
    }

    override fun onError(msg: String) {
        showToast(msg, context!!)
        view?.swipe_container!!.isRefreshing = false
    }

    override fun onRefresh() {
        recyclerViewContent.clear()
        presenter.fetchPosts(0)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        BlackduckApplication.appComponent.inject(this)
        presenter.attachView(this)
        val view : View = inflater.inflate(R.layout.fragment_home, container, false)
        view.recycler_view_main.layoutManager = LinearLayoutManager(activity)
        view.swipe_container.setOnRefreshListener(this)
        view.recycler_view_main.post {
            view.swipe_container.isRefreshing = true
            onRefresh()
        }
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.recycler_view_main?.adapter = HomeAdapter(recyclerViewContent, context)
        setupButtons()
        presenter.onViewCreated()
    }

    private fun setupButtons() {
        btn_messages.setOnClickListener { startActivity(Intent(activity, MessageActivity::class.java)) }
        camera_btn.setOnClickListener {
            if (checkSelfPermission(context!!, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 101)
            } else {
                val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                startActivityForResult(cameraIntent, 102)
            }
        }
    }
}