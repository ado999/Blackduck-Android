package pl.edu.wat.wcy.blackduck.data.request

data class MessageRequest(
    val message: String,
    val toUser: String
)