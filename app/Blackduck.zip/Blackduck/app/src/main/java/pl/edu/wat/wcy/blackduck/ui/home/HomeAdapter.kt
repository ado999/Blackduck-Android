package pl.edu.wat.wcy.blackduck.ui.home

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.squareup.picasso.Picasso
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_comment.view.*
import kotlinx.android.synthetic.main.recycler_row_home.view.*
import kotlinx.android.synthetic.main.recycler_row_home.view.publish_btn
import kotlinx.android.synthetic.main.recycler_row_messages.view.*
import pl.edu.wat.wcy.blackduck.BlackduckApplication
import pl.edu.wat.wcy.blackduck.R
import pl.edu.wat.wcy.blackduck.data.network.Constants
import pl.edu.wat.wcy.blackduck.data.network.PortalApi
import pl.edu.wat.wcy.blackduck.data.preference.Key
import pl.edu.wat.wcy.blackduck.data.preference.PrefsManager
import pl.edu.wat.wcy.blackduck.data.request.CommentRequest
import pl.edu.wat.wcy.blackduck.data.request.RateRequest
import pl.edu.wat.wcy.blackduck.data.responses.PostResponse
import pl.edu.wat.wcy.blackduck.data.responses.RateResponse
import pl.edu.wat.wcy.blackduck.ui.comment.CommentActivity
import pl.edu.wat.wcy.blackduck.ui.conversation.ConversationActivity
import pl.edu.wat.wcy.blackduck.ui.main.MainActivity
import pl.edu.wat.wcy.blackduck.ui.main.SectionsStatePageAdapter
import pl.edu.wat.wcy.blackduck.util.BasicTextWatcher
import pl.edu.wat.wcy.blackduck.util.DateUtils
import javax.inject.Inject

class HomeAdapter(val items: ArrayList<PostResponse>, val context: Context?) :
    RecyclerView.Adapter<HomeAdapter.CustomViewHolder>() {

    @Inject
    lateinit var prefs: PrefsManager

    @Inject
    lateinit var portalApi: PortalApi

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        holder.bindContent(items[position])
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        BlackduckApplication.appComponent.inject(this)
        val layoutInflater = LayoutInflater.from(parent.context)
        val cellForRow = layoutInflater.inflate(R.layout.recycler_row_home, parent, false)
        return CustomViewHolder(cellForRow, prefs, portalApi, context, this)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    class CustomViewHolder(
        val view: View,
        val prefs: PrefsManager,
        val api: PortalApi,
        val context: Context?,
        val adapter: RecyclerView.Adapter<CustomViewHolder>
    ) : RecyclerView.ViewHolder(view) {

        fun bindContent(post: PostResponse) {

            view.postIdTV.text = post.id.toString()
            view.tv_author_nickname.text = post.author.username
            view.tv_comment_count.text = post.comments.size.toString()
            view.tv_likes.text = "%.2f".format(post.rate)
            Picasso.get()
                .load(post.contentUrl)
                .placeholder(R.drawable.loading)
                .error(R.drawable.placeholder)
                .into(view.iv_image)
            Picasso.get()
                .load(post.author.profilePhotoUrl)
                .into(view.btn_author_avatar)
            Picasso.get()
                .load(prefs.loadUser().profilePhotoUrl)
                .error(R.drawable.profile_placeholder)
                .into(view.userProfilePicture)
            bindStars(post.rates, null)
            setupListeners(post)
        }

        private fun bindStars(rates: List<RateResponse>, rate: Int?) {
            var userRate: Int? =
                rates.firstOrNull { it.fromUser.username == prefs.loadUser().displayName }
                    ?.rate
            if (userRate == null) userRate = 0
            if (rate != null) userRate = rate

            when (userRate) {
                5 -> {
                    view.star1.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star2.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star3.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star4.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star5.setImageResource(R.drawable.ic_star_fill_24dp)
                }
                4 -> {
                    view.star1.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star2.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star3.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star4.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star5.setImageResource(R.drawable.ic_star_border_24dp)
                }
                3 -> {
                    view.star1.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star2.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star3.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star4.setImageResource(R.drawable.ic_star_border_24dp)
                    view.star5.setImageResource(R.drawable.ic_star_border_24dp)
                }
                2 -> {
                    view.star1.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star2.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star3.setImageResource(R.drawable.ic_star_border_24dp)
                    view.star4.setImageResource(R.drawable.ic_star_border_24dp)
                    view.star5.setImageResource(R.drawable.ic_star_border_24dp)
                }
                1 -> {
                    view.star1.setImageResource(R.drawable.ic_star_fill_24dp)
                    view.star2.setImageResource(R.drawable.ic_star_border_24dp)
                    view.star3.setImageResource(R.drawable.ic_star_border_24dp)
                    view.star4.setImageResource(R.drawable.ic_star_border_24dp)
                    view.star5.setImageResource(R.drawable.ic_star_border_24dp)
                }
            }

        }

        private fun setupListeners(post: PostResponse) {
            view.btn_save.setOnClickListener {
                savePost(view.postIdTV.text.toString().toInt())
            }
            view.btn_comment.setOnClickListener {
                showComments(view.postIdTV.text.toString().toInt())
            }
            view.star1.setOnClickListener {
                rate(1, view.postIdTV.text.toString().toInt())
            }
            view.star2.setOnClickListener {
                rate(2, view.postIdTV.text.toString().toInt())
            }
            view.star3.setOnClickListener {
                rate(3, view.postIdTV.text.toString().toInt())
            }
            view.star4.setOnClickListener {
                rate(4, view.postIdTV.text.toString().toInt())
            }
            view.star5.setOnClickListener {
                rate(5, view.postIdTV.text.toString().toInt())
            }

            view.textInputEditText.addTextChangedListener(BasicTextWatcher(view.publish_btn))
            view.publish_btn.setOnClickListener {
                api.comment(
                    Constants.APPLICATION_JSON,
                    Constants.APPLICATION_JSON,
                    prefs.loadString(Key.TOKEN),
                    CommentRequest(view.postIdTV.text.toString().toInt(), view.textInputEditText.text.toString())
                )
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe(
                        {
                            post.comments.add(it)
                            view.textInputEditText.text?.clear()
                            view.textInputEditText.clearFocus()
                            (context as MainActivity).hideKeyboard()
                            adapter.notifyDataSetChanged()
                            Toast.makeText(
                                context,
                                "Komentarz został dodany",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        {
                            Toast.makeText(
                                context,
                                "Coś poszło nie po naszej myśli",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
            }
            view.btn_send.setOnClickListener {
                val text = DateUtils.getDateDiff(post.author.lastActivity)
                val bundle = Bundle()
                bundle.putString(Key.MESSAGE_USERNAME.name, post.author.username)
                bundle.putString(Key.MESSAGE_PROFILE_URL.name, post.author.profilePhotoUrl)
                bundle.putString(Key.MESSAGE_DATE.name, text)
                val intent = Intent(context, ConversationActivity::class.java)
                intent.putExtras(bundle)
                context?.startActivity(intent)
            }
            view.userProfilePicture.setOnClickListener {
                (context as MainActivity).setViewPager(SectionsStatePageAdapter.FragmentName.PROFILE, true)
            }
        }

        @SuppressLint("CheckResult")
        private fun rate(rate: Int, postId: Int) {
            api.rate(
                Constants.APPLICATION_JSON,
                Constants.APPLICATION_JSON,
                prefs.loadString(Key.TOKEN),
                RateRequest(rate, postId)
            )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(
                    {
                        bindStars(listOf(), rate)
                        view.tv_likes.text = "%.2f".format(it)
                    },
                    {
                        Toast.makeText(
                            context,
                            "Coś poszło nie po naszej myśli",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
        }

        private fun savePost(id: Int) {
            Toast.makeText(context, "Zapisano post $id", Toast.LENGTH_SHORT).show()
        }

        private fun showComments(postId: Int) {
            val bundle = Bundle()
            bundle.putInt(Key.POST_ID.name, postId)
            val intent = Intent(context, CommentActivity::class.java)
            intent.putExtras(bundle)
            context?.startActivity(intent)
        }


    }

}


