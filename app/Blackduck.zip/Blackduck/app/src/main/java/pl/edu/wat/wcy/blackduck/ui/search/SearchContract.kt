package pl.edu.wat.wcy.blackduck.ui.search

import pl.edu.wat.wcy.blackduck.ui.base.BaseContract

interface SearchContract {

    interface View: BaseContract.View {

    }

    interface Presenter: BaseContract.Presenter<View> {

    }
}