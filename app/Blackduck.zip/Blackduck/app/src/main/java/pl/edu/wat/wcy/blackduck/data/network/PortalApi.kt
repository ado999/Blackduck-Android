package pl.edu.wat.wcy.blackduck.data.network

import io.reactivex.Observable
import pl.edu.wat.wcy.blackduck.data.request.*
import pl.edu.wat.wcy.blackduck.data.responses.*
import retrofit2.http.*

interface PortalApi {

    @POST(Configuration.apiLogin)
    fun login(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Body loginRequest: LoginRequest
    ): Observable<LoginResponse>

    @POST(Configuration.apiSignUp)
    fun signup(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Body loginRequest: SignupRequest
    ): Observable<SignupResponse>

    @GET(Configuration.apiPosts)
    fun getPosts(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String,
        @Query(Constants.PAGE) page: Int,
        @Query(Constants.SIZE) size: Int = 10
    ): Observable<PageResponse<PostResponse>>

    @GET(Configuration.apiPost)
    fun getPost(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String,
        @Query(Constants.POST_ID_QUERY) id: Int
    ): Observable<PostResponse>

    @POST(Configuration.apiRate)
    fun rate(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String,
        @Body rateRequest: RateRequest
    ): Observable<Double>

    @POST(Configuration.apiPutComment)
    fun comment(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String,
        @Body commentRequest: CommentRequest
    ): Observable<CommentResponse>

    @GET(Configuration.apiConversations)
    fun getConversations(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String
    ): Observable<List<ConversationResponse>>

    @POST(Configuration.apiMessages)
    fun getMessages(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String,
        @Body getMessageRequest: GetMessagesRequest
    ): Observable<List<MessageResponse>>

    @POST(Configuration.apiSendMessage)
    fun sendMessage(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String,
        @Body getMessageRequest: MessageRequest
    ): Observable<MessageResponse>

    @GET(Configuration.apiMyPosts)
    fun myPosts(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String
    ): Observable<List<PostResponse>>

    @GET(Configuration.apiMyFollowers)
    fun myFollowers(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String
    ): Observable<List<UserShortResponse>>

    @GET(Configuration.apiMyFollowedUsers)
    fun myFollowedUsers(
        @Header(Constants.ACCEPT) consumes: String,
        @Header(Constants.CONTENT_TYPE) produces: String,
        @Header(Constants.AUTHORIZATION) authorisation: String
    ): Observable<List<UserShortResponse>>

}
