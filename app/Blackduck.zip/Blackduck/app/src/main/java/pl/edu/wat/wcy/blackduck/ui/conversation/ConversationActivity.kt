package pl.edu.wat.wcy.blackduck.ui.conversation

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_conversation.*
import pl.edu.wat.wcy.blackduck.BlackduckApplication
import pl.edu.wat.wcy.blackduck.R
import pl.edu.wat.wcy.blackduck.data.preference.Key
import pl.edu.wat.wcy.blackduck.data.request.MessageRequest
import pl.edu.wat.wcy.blackduck.data.responses.MessageResponse
import pl.edu.wat.wcy.blackduck.util.BasicTextWatcher
import javax.inject.Inject

class ConversationActivity: AppCompatActivity(), ConversationContract.View {

    @Inject
    lateinit var presenter: ConversationContract.Presenter

    private var messageUsername: String? = null
    private var messageProfileUrl: String? = null
    private var messageLastDate: String? = null

    private val messages = ArrayList<MessageResponse>()

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        BlackduckApplication.appComponent.inject(this)
        presenter.attachView(this)
        setContentView(R.layout.activity_conversation)
        recycler_view_conversation.layoutManager = LinearLayoutManager(this)
        recycler_view_conversation.adapter = ConversationAdapter(messages, this)
        messageUsername = intent.extras.getString(Key.MESSAGE_USERNAME.name)
        messageProfileUrl = intent.extras.getString(Key.MESSAGE_PROFILE_URL.name)
        messageLastDate = intent.extras.getString(Key.MESSAGE_DATE.name)
        presenter.fetchMessages(messageUsername)
        setupView()
    }

    override fun onMessagesAvailable(messages: List<MessageResponse>?) {
        this.messages.clear()
        this.messages.addAll(messages ?: emptyList())
        this.recycler_view_conversation.adapter?.notifyDataSetChanged()
    }

    override fun onMessageSent(sentMessage: MessageResponse?) {
        this.messages.add(sentMessage!!)
        textInput.text?.clear()
        recycler_view_conversation.smoothScrollToPosition(messages.size)
        recycler_view_conversation.adapter?.notifyDataSetChanged()
    }

    override fun onError(msg: String?) {
        if(msg != null) showToast(msg, this)
    }

    private fun setupView() {
        Picasso.get()
            .load(messageProfileUrl)
            .into(btn_author_avatar)
        textView25.text = messageUsername
        textView28.text = messageLastDate
        if(messageLastDate!!.endsWith("chwilą")) textView29.visibility = View.INVISIBLE
        imageButton.setOnClickListener {
            finish()
        }
        textInput.setOnClickListener {
            recycler_view_conversation.smoothScrollToPosition(messages.size)
        }
        textInput.addTextChangedListener(BasicTextWatcher(sendMessage))
        sendMessage.setOnClickListener {
            presenter.sendMessage(MessageRequest(textInput.text.toString(), messageUsername!!))
        }
    }

}