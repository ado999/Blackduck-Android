package pl.edu.wat.wcy.blackduck.ui.search

class SearchPresenter: SearchContract.Presenter {
    override fun attachView(view: SearchContract.View) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onViewCreated() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onViewDestroyed() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}