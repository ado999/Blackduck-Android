package pl.edu.wat.wcy.blackduck.data.request

data class LoginRequest(
    val username: String? = null,
    val password: String? = null)