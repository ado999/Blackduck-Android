package pl.edu.wat.wcy.blackduck.data.responses

import java.util.ArrayList
import java.util.Date

data class UserResponse(
    val uuid: String? = null,
    val username: String? = null,
    val displayName: String? = null,
    val fullName: String? = null,
    val creationDate: Date? = null,
    val profilePhotoUrl: String? = null,
    val profileBackgroundUrl: String? = null,
    val posts: ArrayList<PostResponse>? = null,
    val followers: ArrayList<UserShortResponse>? = null,
    val description: String? = null,
    val folders: ArrayList<FolderResponse>? = null,
    val followedUsers: ArrayList<UserShortResponse>? = null
    )