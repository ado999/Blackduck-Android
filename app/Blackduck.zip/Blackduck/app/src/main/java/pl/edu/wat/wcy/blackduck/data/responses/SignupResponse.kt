package pl.edu.wat.wcy.blackduck.data.responses

data class SignupResponse(val success: Boolean, val message: String)