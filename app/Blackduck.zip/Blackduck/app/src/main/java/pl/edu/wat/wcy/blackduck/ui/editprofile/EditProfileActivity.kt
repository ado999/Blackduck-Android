package pl.edu.wat.wcy.blackduck.ui.editprofile

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Toast
import kotlinx.android.synthetic.main.top_menu_edit_profile.*
import pl.edu.wat.wcy.blackduck.R

class EditProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        setupButtons()
    }

    private fun setupButtons() {
        btn_close.setOnClickListener { finish() }
        btn_save.setOnClickListener {
            Toast.makeText(this, "save", Toast.LENGTH_SHORT).show()
        }
    }

}