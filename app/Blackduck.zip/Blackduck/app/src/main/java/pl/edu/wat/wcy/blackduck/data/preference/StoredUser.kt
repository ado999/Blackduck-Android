package pl.edu.wat.wcy.blackduck.data.preference

data class StoredUser(
    val token: String,
    val uuid: String,
    val displayName: String,
    val fullname: String,
    val creationDate: String,
    val profilePhotoUrl: String,
    val profileBackgroundUrl: String,
    val description: String
)