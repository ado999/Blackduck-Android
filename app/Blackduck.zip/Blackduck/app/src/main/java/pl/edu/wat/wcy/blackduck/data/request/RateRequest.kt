package pl.edu.wat.wcy.blackduck.data.request

data class RateRequest(
    val rate: Int,
    val postId: Int
)