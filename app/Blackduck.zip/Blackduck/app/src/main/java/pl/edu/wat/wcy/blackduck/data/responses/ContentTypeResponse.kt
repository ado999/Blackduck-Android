package pl.edu.wat.wcy.blackduck.data.responses

enum class ContentTypeResponse {
    PHOTO,
    VIDEO
}
