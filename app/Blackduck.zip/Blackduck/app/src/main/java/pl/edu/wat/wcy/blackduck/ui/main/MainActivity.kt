package pl.edu.wat.wcy.blackduck.ui.main

import android.app.Activity
import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import pl.edu.wat.wcy.blackduck.BlackduckApplication
import pl.edu.wat.wcy.blackduck.R
import pl.edu.wat.wcy.blackduck.data.preference.Key
import pl.edu.wat.wcy.blackduck.data.preference.PrefsManager
import pl.edu.wat.wcy.blackduck.ui.home.HomeFragment
import pl.edu.wat.wcy.blackduck.ui.login.LoginFragment
import pl.edu.wat.wcy.blackduck.ui.profile.ProfileFragment
import pl.edu.wat.wcy.blackduck.ui.register.RegisterFragment
import pl.edu.wat.wcy.blackduck.ui.search.SearchFragment
import pl.edu.wat.wcy.blackduck.ui.settings.SettingsFragment
import javax.inject.Inject

class MainActivity : AppCompatActivity(), MainContract.View {

    @Inject
    lateinit var prefs: PrefsManager

    private var sectionsStatePageAdapter: SectionsStatePageAdapter? = null

    private var viewPager: ViewPager? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        BlackduckApplication.appComponent.inject(this)

        setContentView(R.layout.activity_main)

        sectionsStatePageAdapter =
            SectionsStatePageAdapter(supportFragmentManager)
        viewPager = view_pager
        if(isUserLoggedId())
            enterLoggedInMode()
        else
            enterLoginMode()
    }

    fun isUserLoggedId() = prefs.loadString(Key.TOKEN) != ""

    fun enterLoginMode() {
        bottom_menu.visibility = View.GONE
        val adapter = SectionsStatePageAdapter(supportFragmentManager)
        adapter.addItem(SectionsStatePageAdapter.FragmentName.LOGIN, LoginFragment())
        adapter.addItem(SectionsStatePageAdapter.FragmentName.REGISTER, RegisterFragment())
        viewPager?.adapter = adapter
    }

    fun enterLoggedInMode() {
        bottom_menu.visibility = View.VISIBLE
        val adapter = SectionsStatePageAdapter(supportFragmentManager)
        adapter.addItem(SectionsStatePageAdapter.FragmentName.HOME, HomeFragment())
        adapter.addItem(SectionsStatePageAdapter.FragmentName.SEARCH, SearchFragment())
        adapter.addItem(SectionsStatePageAdapter.FragmentName.PROFILE, ProfileFragment())
        adapter.addItem(SectionsStatePageAdapter.FragmentName.SETTINGS, SettingsFragment())
        viewPager?.adapter = adapter
        setupButtons()
    }

    fun setViewPager(fragmentName: SectionsStatePageAdapter.FragmentName, smoothScroll: Boolean) {
        viewPager?.setCurrentItem((viewPager?.adapter as SectionsStatePageAdapter).getItemIndex(fragmentName), smoothScroll)
    }

    fun hideKeyboard(){
        val imm = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        var view = currentFocus
        if (view == null){
            view = View(this)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun setupButtons() {
        bottom_menu.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.btn_menu_home -> setViewPager(SectionsStatePageAdapter.FragmentName.HOME, true)
                R.id.btn_menu_search -> setViewPager(SectionsStatePageAdapter.FragmentName.SEARCH, true)
                R.id.btn_menu_add -> Toast.makeText(this, "add", Toast.LENGTH_SHORT).show()
                R.id.btn_menu_heart -> Toast.makeText(this, "like", Toast.LENGTH_SHORT).show()
                R.id.btn_menu_person -> setViewPager(SectionsStatePageAdapter.FragmentName.PROFILE, true)
            }
            true
        }
    }

}
