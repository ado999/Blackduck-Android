package pl.edu.wat.wcy.blackduck.data.network

object Configuration {

    private const val PROTOCOL = "http"

//     const val IP = "192.168.43.75" // redmi hotspot
//     const val IP = "172.28.118.19" //akademik
     const val IP = "192.168.0.11" //madzia

    private const val PORT = "8080"

    const val BASE_URL = "$PROTOCOL://$IP:$PORT"

    const val WS_URL = "http://172.28.118.19:8080/socket/"

    const val apiLogin = "/login"

    const val apiSignUp = "/signup"

    const val apiPosts = "/posts"

    const val apiPost = "/posts/post"

    const val apiRate = "/rates"

    const val apiPutComment = "/comments"

    const val apiSendMessage = "/chat/sendMessage"

    const val apiConversations = "/chat/conversations"

    const val apiMessages = "/chat/messages"

    const val apiMyPosts = "/posts/my"

    const val apiMyFollowers = "/followers"

    const val apiMyFollowedUsers = "/followedUsers"

}