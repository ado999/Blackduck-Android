package pl.edu.wat.wcy.blackduck.ui.editprofile

import pl.edu.wat.wcy.blackduck.ui.base.BaseContract

interface EditProfileContract {

    interface View: BaseContract.View {

    }

    interface Presenter: BaseContract.Presenter<View> {

    }

}